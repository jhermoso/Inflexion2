## What steps will reproduce this issue?

_Write problem description here_

### Expected outcome

_Write expected outcome here_


--
### Environment

- MahApps.Metro __v?.?.?__
- Windows __??__
- Visual Studio __20xx__
- .NET Framework __?.?__
