﻿namespace MahApps.Metro.Controls.Dialogs
{
    /// <summary>
    /// An implementation of BaseMetroDialog allowing arbitrary content.
    /// </summary>
    public class CustomDialog : BaseMetroDialog
    { }
}