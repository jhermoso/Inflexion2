﻿using System;

namespace MahApps.Metro.Controls.Dialogs
{
    public class DialogStateChangedEventArgs: EventArgs
    {
        internal DialogStateChangedEventArgs()
        {
        }
    }
}
