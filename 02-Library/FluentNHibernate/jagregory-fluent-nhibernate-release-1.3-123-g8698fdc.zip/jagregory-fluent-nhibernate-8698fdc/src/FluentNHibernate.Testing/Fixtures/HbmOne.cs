﻿namespace FluentNHibernate.Testing.Fixtures
{
    public class HbmOne
    {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
    }
}
