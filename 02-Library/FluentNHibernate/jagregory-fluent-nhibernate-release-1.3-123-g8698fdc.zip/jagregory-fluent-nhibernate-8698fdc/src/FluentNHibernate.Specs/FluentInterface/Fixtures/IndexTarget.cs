namespace FluentNHibernate.Specs.FluentInterface.Fixtures
{
    class IndexTarget
    {}
}