﻿using FluentNHibernate.Mapping;

namespace FluentNHibernate.Specs.PersistenceModel.Fixtures
{
    class UnionChildEntityMap : SubclassMap<UnionChildEntity>
    {}
}