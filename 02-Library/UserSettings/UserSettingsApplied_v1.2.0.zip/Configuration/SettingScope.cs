// -- FILE ------------------------------------------------------------------
// name       : SettingScope.cs
// created    : Jani Giannoudis - 2008.04.25
// language   : c#
// environment: .NET 2.0
// --------------------------------------------------------------------------

namespace Itenso.Configuration
{

	// ------------------------------------------------------------------------
	public enum SettingScope
	{

		Application,
		User,

	} // enum SettingScope

} // namespace Itenso.Configuration
// -- EOF -------------------------------------------------------------------
