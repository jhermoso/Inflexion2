﻿using System;
using System.Collections.Generic;

namespace MvvmValidation.Internal
{
	internal class ValidationRuleCollection : List<ValidationRule>
	{
	}
}