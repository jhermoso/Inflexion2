﻿using System;
using System.Windows.Controls;

namespace FormValidationExample.View
{
	public partial class FormControl : UserControl
	{
		public FormControl()
		{
			InitializeComponent();
		}
	}
}
