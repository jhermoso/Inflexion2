﻿using System;

namespace MvvmValidation.Tests.Fakes
{
	public class DummyViewModel : ViewModelBase
	{
		public string Foo { get; set; }
		public string Bar { get; set; }
	}
}