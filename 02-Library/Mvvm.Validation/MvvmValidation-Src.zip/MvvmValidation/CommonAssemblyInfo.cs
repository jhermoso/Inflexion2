﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("MvvmValidation")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CtrlSoft")]
[assembly: AssemblyProduct("MvvmValidation")]
[assembly: AssemblyCopyright("Copyright © Pavlo Glazkov 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
