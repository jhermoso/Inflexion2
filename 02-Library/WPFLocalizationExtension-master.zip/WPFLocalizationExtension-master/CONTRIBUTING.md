Thanks for reporting an issue!

Please keep in mind that this project is not actively developed and that @MrCircuit and I (@SeriousM) don't work full-time on it.

If you have a clue how to resolve the issue please try to resolve it yourself and send us a Pull Request including unit tests.

Open-Source means not only the "free" availability of source code, it also means that the users are free to contribute to it to make it better.

Thank you for your help and understanding.
